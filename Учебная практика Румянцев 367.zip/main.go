package main

import (
 "bufio"
 "context"
 "flag"
 "fmt"
 "log"
 "os"
 "os/signal"
 "strings"
 "sync"
 "syscall"
 "time"
 "net"
)

type PingResult struct {
 Host      string
 Success   bool
 Latency   time.Duration
 Attempt   int
 Timestamp time.Time
 Error     error
}

type Config struct {
 File     string
 Count    int
 Monitor  bool
 LogFile  string
}

func main() {
 config := parseFlags()

 hosts, err := readHostsFromFile(config.File)
 if err != nil {
  log.Fatalf("Ошибка чтения файла: %v", err)
 }

 if len(hosts) == 0 {
  log.Fatal("Список хостов пуст")
 }

 logFile, err := os.OpenFile(config.LogFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
 if err != nil {
  log.Fatalf("Ошибка создания файла лога: %v", err)
 }
 defer logFile.Close()

 fileLogger := log.New(logFile, "", 0)

 if config.Monitor {
  runMonitorMode(hosts, config, fileLogger)
 } else {
  runSingleMode(hosts, config, fileLogger)
 }
}

func parseFlags() *Config {
 config := &Config{
  LogFile: "monitor.log",
 }

 flag.StringVar(&config.File, "f", "", "Файл со списком хостов (обязательный)")
 flag.IntVar(&config.Count, "c", 3, "Количество попыток проверки")
 flag.BoolVar(&config.Monitor, "monitor", false, "Режим постоянного мониторинга")
 flag.Parse()

 if config.File == "" {
  fmt.Println("Необходимо указать файл с хостами через флаг -f")
  flag.Usage()
  os.Exit(1)
 }

 return config
}

func readHostsFromFile(filename string) ([]string, error) {
 file, err := os.Open(filename)
 if err != nil {
  return nil, err
 }
 defer file.Close()

 var hosts []string
 scanner := bufio.NewScanner(file)
 for scanner.Scan() {
  host := strings.TrimSpace(scanner.Text())
  if host != "" && !strings.HasPrefix(host, "#") {
   hosts = append(hosts, host)
  }
 }

 return hosts, scanner.Err()
}

func pingHost(host string) (bool, time.Duration, error) {
 start := time.Now()
 
 conn, err := net.DialTimeout("tcp", net.JoinHostPort(host, "80"), 2*time.Second)
 
 latency := time.Since(start)
 
 if err != nil {
  return false, latency, err
 }
 
 conn.Close()
 return true, latency, nil
}

func runSingleMode(hosts []string, config *Config, fileLogger *log.Logger) {
 fmt.Printf("\n%-20s %-10s %-12s %s\n", "Хост", "Статус", "Время ответа", "Попытка")
 fmt.Println(strings.Repeat("-", 60))

 for _, host := range hosts {
  for attempt := 1; attempt <= config.Count; attempt++ {
   success, latency, err := pingHost(host)
   
   result := PingResult{
    Host:      host,
    Success:   success,
    Latency:   latency,
    Attempt:   attempt,
    Timestamp: time.Now(),
    Error:     err,
   }

   printResult(result, config.Count)
   
   logToFile(result, fileLogger)
   
   if attempt < config.Count {
    time.Sleep(1 * time.Second)
   }
  }
 }
}

func runMonitorMode(hosts []string, config *Config, fileLogger *log.Logger) {
 fmt.Println("Запуск режима постоянного мониторинга")
 fmt.Println("Нажмите Ctrl+C для завершения...\n")

 ctx, cancel := context.WithCancel(context.Background())
 defer cancel()

 results := make(chan PingResult, len(hosts))
 
 sigChan := make(chan os.Signal, 1)
 signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

 var wg sync.WaitGroup

 printHeader()
 for _, host := range hosts {
  wg.Add(1)
  go monitorWorker(ctx, &wg, host, results)
 }

 done := make(chan bool)
 go resultListener(results, fileLogger, done)

 <-sigChan
 fmt.Println("\nПолучен сигнал завершения. Остановка...")

 cancel()

 wg.Wait()
 
 close(results)
 
 <-done
 
 fmt.Println("Программа завершена.")
}

func monitorWorker(ctx context.Context, wg *sync.WaitGroup, host string, results chan<- PingResult) {
 defer wg.Done()

 ticker := time.NewTicker(5 * time.Second)
 defer ticker.Stop()

 attempt := 1

 for {
  select {
  case <-ctx.Done():
   return
  case <-ticker.C:
   success, latency, err := pingHost(host)
   
   result := PingResult{
    Host:      host,
    Success:   success,
    Latency:   latency,
    Attempt:   attempt,
    Timestamp: time.Now(),
    Error:     err,
   }
   
   select {
   case results <- result:
   default:
   }
   
   attempt++
  }
 }
}


func resultListener(results <-chan PingResult, fileLogger *log.Logger, done chan<- bool) {
 for result := range results {
  printMonitorResult(result)
  
  logToFile(result, fileLogger)
 }
 done <- true
}

func printHeader() {
 fmt.Printf("\n%-20s %-25s %-10s %-12s %s\n", 
  "Хост", "Время", "Статус", "Задержка", "Попытка")
 fmt.Println(strings.Repeat("-", 80))
}

func printResult(r PingResult, maxAttempts int) {
 status := "OK"
 latencyStr := fmt.Sprintf("%dms", r.Latency.Milliseconds())
 
 if !r.Success {
  status = "Timeout"
  latencyStr = "0ms"
 }
 
 fmt.Printf("%-20s %-10s %-12s %d/%d\n", 
  r.Host, 
  status, 
  latencyStr, 
  r.Attempt, 
  maxAttempts)
}

func printMonitorResult(r PingResult) {
 status := "OK"
 latencyStr := fmt.Sprintf("%dms", r.Latency.Milliseconds())
 
 if !r.Success {
  status = "Timeout"
  latencyStr = "0ms"
  if r.Error != nil {
   status = fmt.Sprintf("Error")
  }
 }
 
 fmt.Printf("%-20s %-25s %-10s %-12s %d\n", 
  r.Host, 
  r.Timestamp.Format("2006-01-02 15:04:05"), 
  status, 
  latencyStr, 
  r.Attempt)
}

func logToFile(r PingResult, logger *log.Logger) {
 status := "OK"
 latencyStr := fmt.Sprintf("%dms", r.Latency.Milliseconds())
 
 if !r.Success {
  status = "Timeout"
  latencyStr = "0ms"
  if r.Error != nil {
   status = "ERROR"
  }
 }
 
 logger.Printf("%s | %s | %s | %s", 
  r.Timestamp.Format("2006-01-02 15:04:05"),
  r.Host,
  status,
  latencyStr)
}