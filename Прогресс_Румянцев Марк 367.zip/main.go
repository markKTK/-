package main

import (
	"bufio"
	"flag"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

type PingResult struct {
	Host      string
	Success   bool
	Latency   time.Duration
	Attempt   int
	Error     error
}

const (
	maxAttempts = 3
	timeout     = 2 * time.Second
)

func main() {
	filePath := flag.String("f", "", "Файл со списком хостов (обязательный)")
	countFlag := flag.Int("c", 3, "Количество попыток (всегда используется 3)")
	flag.Parse()

	if *filePath == "" {
		fmt.Println("Ошибка: необходимо указать файл с хостами через флаг -f")
		fmt.Println("Пример: go run main.go -f hosts.txt -c 3")
		flag.Usage()
		os.Exit(1)
	}

	hosts, err := readHostsFromFile(*filePath)
	if err != nil {
		fmt.Printf("Ошибка чтения файла %s: %v\n", *filePath, err)
		os.Exit(1)
	}

	if len(hosts) == 0 {
		fmt.Println("Список хостов пуст")
		os.Exit(1)
	}

	if *countFlag != maxAttempts {
		fmt.Printf("Примечание: программа всегда выполняет %d попытки (переданное значение -c %d игнорируется)\n", maxAttempts, *countFlag)
	}

	fmt.Printf("\n%-20s %-10s %-12s %s\n", "Хост", "Статус", "Время ответа", "Попытка")
	fmt.Println(strings.Repeat("-", 60))

	for _, host := range hosts {
		for attempt := 1; attempt <= maxAttempts; attempt++ {
			result := pingHost(host, attempt)
			
			printResult(result)
			
			if attempt < maxAttempts {
				time.Sleep(1 * time.Second)
			}
		}
	}
}

func readHostsFromFile(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var hosts []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		host := strings.TrimSpace(scanner.Text())
		if host != "" && !strings.HasPrefix(host, "#") {
			hosts = append(hosts, host)
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return hosts, nil
}

func pingHost(host string, attempt int) PingResult {
	start := time.Now()
	
	conn, err := net.DialTimeout("tcp", net.JoinHostPort(host, "80"), timeout)
	
	latency := time.Since(start)
	
	result := PingResult{
		Host:    host,
		Attempt: attempt,
		Latency: latency,
	}
	
	if err != nil {
		result.Success = false
		result.Error = err
	} else {
		result.Success = true
		conn.Close()
	}
	
	return result
}

func printResult(r PingResult) {
	status := "OK"
	latencyStr := fmt.Sprintf("%dms", r.Latency.Milliseconds())
	
	if !r.Success {
		status = "Timeout"
		latencyStr = "0ms"
	}
	
	fmt.Printf("%-20s %-10s %-12s %d/%d\n", 
		r.Host, 
		status, 
		latencyStr, 
		r.Attempt, 
		maxAttempts)
}